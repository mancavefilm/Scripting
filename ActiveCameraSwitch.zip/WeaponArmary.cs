﻿using UnityEngine;
using System.Collections;

public class WeaponArmary : MonoBehaviour {

	public static int rockets=0;
	public int totalRockets;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		totalRockets = rockets;
	
	}
}
