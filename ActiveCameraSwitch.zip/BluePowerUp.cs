using UnityEngine;
using System.Collections;

//this inherits from the PowerUpBase Class
public class BluePowerUp : PowerUpBase {


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
